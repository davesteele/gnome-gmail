
[![Build Status](https://travis-ci.org/davesteele/gnome-gmail.svg?branch=master)](https://travis-ci.org/davesteele/gnome-gmail)
[![Packaging status](https://repology.org/badge/tiny-repos/gnome-gmail.svg)](https://repology.org/metapackage/gnome-gmail)

## GNOME Gmail

This is part of the GNOME Gmail project.

Home page: https://davesteele.github.io/gnome-gmail/

Once installed, Gmail can act as the default mail application for the desktop.
'Mailto' links, file attachments, Nautilus/LibreOffice "Send to", etc. are
supported.

[Screenshots](https://davesteele.github.io/gnome-gmail/screenshots.html)
